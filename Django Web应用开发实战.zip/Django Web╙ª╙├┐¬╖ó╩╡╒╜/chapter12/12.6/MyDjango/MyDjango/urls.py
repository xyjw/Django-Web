
from django.urls import path, include
from .consumers import ChatConsumer

urlpatterns = [
    path('', include(('chat.urls', 'chat'), namespace='chat'))
]

websocket_urlpatterns = [
    path('ws/chat/<room_name>/', ChatConsumer),
]
